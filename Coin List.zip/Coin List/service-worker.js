const CACHE_NAME = "coin-cache-v1";

//install cache
self.addEventListener("fetch",(event) => {
    event.respondWith(caches.open(CACHE_NAME)
    .then(async (cache) => {
        const cachedResponse = await cache.match(event.request);
        if(cachedResponse) return cachedResponse;

        const networkResponse = await  fetch(event.request);
        event.waitUntil(
            cache.put(event.request, networkResponse.clone())
        );
        return networkResponse;
    }));
});

//hapus cache lama
self.addEventListener("activate",(event) => {
    event.waitUntil(
        caches.keys().then((cacheNames) => {
            return Promise.all(
                cacheNames.map((cacheName) => {
                    if(cacheName != CACHE_NAME){
                        console.log("Serviceworker: cache "+cacheName+" dihapus");

                        return caches.delete(cacheName);
                    }
                })
            );
        })
    );
});